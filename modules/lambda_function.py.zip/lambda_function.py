import json
import boto3

def lambda_handler(event, context):
    dynamodb_client = boto3.client('dynamodb')
    res = dynamodb_client.update_item(
            TableName = 'VisitorCountDB',
            Key = {
                'Id': {
                    'S': '1'
                }
            },
            
            ExpressionAttributeNames = {
                '#Count': 'Count'
            },
            ExpressionAttributeValues = {
                ':Increase': {
                    'N': '1',
                },
            },
           UpdateExpression = 'SET #Count = #Count + :Increase',
           ReturnValues = 'UPDATED_NEW',
           )
    count = res['Attributes']['Count']['N']
    
    return {
        'statusCode': res['ResponseMetadata'] ['HTTPStatusCode'],
        'count' : int(count)
    }

    
